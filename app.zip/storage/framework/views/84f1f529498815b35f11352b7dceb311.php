<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($reinitialisation ? 'Réinitialisation du mot de passe' : 'Vérification de votre email'); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #f8f9fa;
            padding: 20px;
            text-align: center;
            border-bottom: 3px solid #17a2b8;
        }
        .content {
            padding: 30px 20px;
            background-color: #ffffff;
        }
        .bouton {
            display: inline-block;
            background-color: #17a2b8;
            color: #ffffff;
            text-decoration: none;
            padding: 12px 28px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .footer {
            text-align: center;
            padding: 20px;
            font-size: 12px;
            color: #6c757d;
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?php echo e($ressortissant->entity->nom); ?></h1>
    </div>

    <div class="content">
        <h2>Bonjour <?php echo e($ressortissant->prenom); ?> <?php echo e($ressortissant->nom); ?>,</h2>

        <?php if($reinitialisation): ?>
            <p>Vous avez demandé la réinitialisation du mot de passe de votre espace consulaire.</p>

            <p>Pour choisir un nouveau mot de passe, cliquez sur le bouton ci-dessous :</p>

            <p style="text-align: center;">
                <a href="<?php echo e($lien); ?>" class="bouton">Choisir un nouveau mot de passe</a>
            </p>

            <p>Ce lien est valable 7 jours. Si vous n'êtes pas à l'origine de cette demande, vous pouvez ignorer cet email — votre mot de passe actuel reste inchangé.</p>
        <?php else: ?>
            <p><strong>Merci de vous être inscrit(e) au registre consulaire.</strong></p>

            <p>Il ne reste qu'une étape avant d'accéder à votre espace : confirmez votre adresse email en cliquant sur le bouton ci-dessous.</p>

            <p style="text-align: center;">
                <a href="<?php echo e($lien); ?>" class="bouton">Vérifier mon email</a>
            </p>

            <p>Ce lien est valable 7 jours. Si vous n'êtes pas à l'origine de cette inscription, vous pouvez ignorer cet email.</p>
        <?php endif; ?>

        <p>Cordialement,</p>
        <p><strong><?php echo e($ressortissant->entity->nom_court ?? $ressortissant->entity->nom); ?></strong></p>
    </div>

    <div class="footer">
        <p><?php echo e($ressortissant->entity->nom); ?></p>
        <?php if($ressortissant->entity->ville_siege): ?>
            <p><?php echo e($ressortissant->entity->ville_siege); ?> — <?php echo e($ressortissant->entity->pays_accueil); ?></p>
        <?php endif; ?>
        <?php if($ressortissant->entity->email || $ressortissant->entity->telephone): ?>
            <p>
                <?php if($ressortissant->entity->email): ?> Email: <?php echo e($ressortissant->entity->email); ?> <?php endif; ?>
                <?php if($ressortissant->entity->telephone): ?> | Tél: <?php echo e($ressortissant->entity->telephone); ?> <?php endif; ?>
            </p>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\wamp64\www\consulat.api\resources\views/emails/verification-ressortissant.blade.php ENDPATH**/ ?>